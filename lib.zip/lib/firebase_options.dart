// Secure Firebase Options using environment variables
// ignore_for_file: type=lint
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, kIsWeb, TargetPlatform;
import 'package:flutter_dotenv/flutter_dotenv.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    // Ensure dotenv is loaded (called after in FirebaseService)
    if (!dotenv.isInitialized) {
      throw Exception('dotenv must be loaded before accessing FirebaseOptions');
    }

    if (kIsWeb) {
      return _getWebOptions();
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return _getAndroidOptions();
      case TargetPlatform.iOS:
        return _getIOSOptions();
      case TargetPlatform.macOS:
        return _getMacOSOptions();
      case TargetPlatform.windows:
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for this platform. '
          'Use FlutterFire CLI to configure: flutterfire configure',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static FirebaseOptions _getWebOptions() {
    return FirebaseOptions(
      apiKey: dotenv.env['FIREBASE_WEB_API_KEY'] ?? 'YOUR_WEB_API_KEY',
      appId: dotenv.env['FIREBASE_WEB_APP_ID'] ?? 'YOUR_WEB_APP_ID',
      messagingSenderId: dotenv.env['FIREBASE_WEB_MESSAGING_SENDER_ID'] ?? 'YOUR_MESSAGING_SENDER_ID',
      projectId: dotenv.env['FIREBASE_PROJECT_ID'] ?? 'your-project-id',
      authDomain: dotenv.env['FIREBASE_WEB_AUTH_DOMAIN'] ?? 'your-project.firebaseapp.com',
      storageBucket: dotenv.env['FIREBASE_STORAGE_BUCKET'] ?? 'your-project.firebasestorage.app',
      measurementId: dotenv.env['FIREBASE_WEB_MEASUREMENT_ID'],
    );
  }

  static FirebaseOptions _getAndroidOptions() {
    return FirebaseOptions(
      apiKey: dotenv.env['FIREBASE_ANDROID_API_KEY'] ?? 'YOUR_ANDROID_API_KEY',
      appId: dotenv.env['FIREBASE_ANDROID_APP_ID'] ?? 'YOUR_ANDROID_APP_ID',
      messagingSenderId: dotenv.env['FIREBASE_WEB_MESSAGING_SENDER_ID'] ?? 'YOUR_MESSAGING_SENDER_ID',
      projectId: dotenv.env['FIREBASE_PROJECT_ID'] ?? 'your-project-id',
      storageBucket: dotenv.env['FIREBASE_STORAGE_BUCKET'] ?? 'your-project.firebasestorage.app',
    );
  }

  static FirebaseOptions _getIOSOptions() {
    return FirebaseOptions(
      apiKey: dotenv.env['FIREBASE_IOS_API_KEY'] ?? 'YOUR_IOS_API_KEY',
      appId: dotenv.env['FIREBASE_IOS_APP_ID'] ?? 'YOUR_IOS_APP_ID',
      messagingSenderId: dotenv.env['FIREBASE_WEB_MESSAGING_SENDER_ID'] ?? 'YOUR_MESSAGING_SENDER_ID',
      projectId: dotenv.env['FIREBASE_PROJECT_ID'] ?? 'your-project-id',
      storageBucket: dotenv.env['FIREBASE_STORAGE_BUCKET'] ?? 'your-project.firebasestorage.app',
      iosBundleId: dotenv.env['FIREBASE_IOS_BUNDLE_ID'] ?? 'com.example.chimere',
    );
  }

  static FirebaseOptions _getMacOSOptions() {
    return FirebaseOptions(
      apiKey: dotenv.env['FIREBASE_MACOS_API_KEY'] ?? 'YOUR_MACOS_API_KEY',
      appId: dotenv.env['FIREBASE_MACOS_APP_ID'] ?? 'YOUR_MACOS_APP_ID',
      messagingSenderId: dotenv.env['FIREBASE_WEB_MESSAGING_SENDER_ID'] ?? 'YOUR_MESSAGING_SENDER_ID',
      projectId: dotenv.env['FIREBASE_PROJECT_ID'] ?? 'your-project-id',
      storageBucket: dotenv.env['FIREBASE_STORAGE_BUCKET'] ?? 'your-project.firebasestorage.app',
    );
  }
}

